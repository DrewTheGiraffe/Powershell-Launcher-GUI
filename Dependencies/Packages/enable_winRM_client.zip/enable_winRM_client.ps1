﻿# Script by Drew J Burgess 2-3 FA S6.. Based off of Mr. Sloan Fort Bliss NEC research.
Write-Host "Setting Firewall Rules for PS Remoting`n" -ForegroundColor Green -BackgroundColor Black
Enable-PSRemoting -SkipNetworkProfileCheck -Force
New-NetFirewallRule -DisplayName "Remote Management" -Direction Inbound -LocalPort 5986 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "Remote Management" -Direction Inbound -LocalPort 445 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "Remote Management" -Direction Inbound -LocalPort 139 -Protocol TCP -Action Allow
New-NetFirewallRule -DisplayName "Remote Management" -Direction Inbound -LocalPort 5985 -Protocol TCP -Action Allow

Write-Host "`nScript Finished Exiting Safely!`n" -ForegroundColor Green -BackgroundColor Black
Sleep 1
exit